# Gatherly Bot

## Setup

1. Copy `.env.example` to `.env` and fill in your values.
2. Run `npm install`
3. Register slash commands once: `node register-commands.js`
4. Start the bot: `node index.js`

## Deploy to Railway

1. Push this folder to GitHub (inside your Gatherly repo as `bot/`)
2. Create a new Railway project, set Root Directory to `bot`
3. Add env vars: DISCORD_BOT_TOKEN, DISCORD_CLIENT_ID, GATHERLY_GUILD_ID, ANTHROPIC_API_KEY
4. Railway auto-detects the Dockerfile and deploys

## Discord Developer Portal (required one-time setup)

Under Bot, enable all three privileged intents:
- Message Content Intent
- Server Members Intent
- Presence Intent

## Commands

- `/giveaway` - start a giveaway (staff only)
- `/giveaway-end` - end a giveaway early (staff only)
- `/giveaway-reroll` - reroll winners (staff only)
- `/say` - speak as the bot in any channel (staff only)
- `/play` - play music (staff only)
- `/skip`, `/stop`, `/pause`, `/resume` - playback controls
- `/queue`, `/nowplaying` - queue info
- `/volume`, `/loop`, `/shuffle`, `/seek` - playback settings
- `/remove`, `/move` - queue management
- `/dj` - audio effects
- `/lyrics` - get song lyrics
- `/disconnect` - leave voice
- `-join` - join the music voice channel (anyone)
